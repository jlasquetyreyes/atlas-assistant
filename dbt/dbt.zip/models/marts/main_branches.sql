{{
  config(
    materialized='table'
  )
}}

WITH RECURSIVE block_hierarchy AS (
  -- Base case: get all blocks
  SELECT 
    block_id,
    parent_id,
    parent_type,
    block_type,
    text_content,
    created_time,
    last_edited_time,
    page_id,
    -- Start with top-level blocks (direct children of pages)
    CASE 
      WHEN parent_type = 'page' THEN block_id::text
      ELSE NULL
    END as top_block_id,
    -- Track depth to prevent infinite recursion
    0 as depth,
    -- Track path to detect cycles
    ARRAY[block_id] as path
  FROM {{ ref('stg_blocks') }}
  WHERE parent_type = 'page'
  
  UNION ALL
  
  -- Recursive case: get child blocks
  SELECT 
    b.block_id,
    b.parent_id,
    b.parent_type,
    b.block_type,
    b.text_content,
    b.created_time,
    b.last_edited_time,
    b.page_id,
    -- Inherit top_block_id from parent
    bh.top_block_id,
    -- Increment depth
    bh.depth + 1,
    -- Add current block to path
    bh.path || b.block_id
  FROM {{ ref('stg_blocks') }} b
  JOIN block_hierarchy bh ON b.parent_id = bh.block_id
  WHERE 
    -- Prevent infinite recursion (max depth of 10)
    bh.depth < 10
    -- Prevent cycles (block not already in path)
    AND NOT (b.block_id = ANY(bh.path))
    -- Limit recursion for toggle blocks to prevent excessive nesting
    AND (bh.block_type != 'toggle' OR bh.depth < 3)
),
complete_texts AS (
  SELECT 
    top_block_id,
    page_id,
    -- Concatenate all text content in order
    STRING_AGG(
      COALESCE(text_content, ''),
      ' ' ORDER BY depth, created_time
    ) as complete_text,
    -- Calculate metadata
    COUNT(*) as total_blocks,
    MAX(depth) as max_depth,
    MIN(created_time) as first_created,
    MAX(last_edited_time) as last_updated,
    -- Calculate text metrics
    LENGTH(STRING_AGG(COALESCE(text_content, ''), ' ' ORDER BY depth, created_time)) as character_length,
    ARRAY_LENGTH(STRING_TO_ARRAY(STRING_AGG(COALESCE(text_content, ''), ' ' ORDER BY depth, created_time), ' '), 1) as word_length
  FROM block_hierarchy
  WHERE top_block_id IS NOT NULL
  GROUP BY top_block_id, page_id
),
final_output AS (
  SELECT 
    top_block_id,
    page_id,
    complete_text,
    character_length,
    word_length,
    total_blocks,
    max_depth,
    first_created,
    last_updated,
    -- Create vector database ID
    'vector_' || top_block_id as vector_id,
    -- Create metadata JSON
    JSONB_BUILD_OBJECT(
      'page_id', page_id,
      'total_blocks', total_blocks,
      'max_depth', max_depth,
      'first_created', first_created,
      'last_updated', last_updated,
      'character_length', character_length,
      'word_length', word_length
    ) as metadata
  FROM complete_texts
  WHERE 
    -- Only include chunks with meaningful content
    LENGTH(TRIM(complete_text)) > 0
    -- Filter out very short chunks
    AND character_length >= 50
)

SELECT * FROM final_output 